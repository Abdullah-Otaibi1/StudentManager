﻿using System;
using StudentManager.Models;
using StudentManager.Repositories;

namespace StudentManager
{
    class Program
    {
        static void Main(string[] args)
        {
            IRepository repository = new StudentRepository();
            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("\n--- Student Manager ---");
                Console.WriteLine("1. Add Student");
                Console.WriteLine("2. Show All Students");
                Console.WriteLine("3. Update Student");
                Console.WriteLine("4. Delete Student");
                Console.WriteLine("5. Exit");
                Console.Write("Select an option (1-5): ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter student name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter student age: ");
                        int age = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter student GPA: ");
                        double gpa = Convert.ToDouble(Console.ReadLine());

                        Student newStudent = new Student { Name = name, Age = age, GPA = gpa };
                        repository.AddStudent(newStudent);
                        Console.WriteLine("Student added successfully.");
                        break;

                    case "2":
                        var students = repository.GetAllStudents();
                        Console.WriteLine("--- Student List ---");
                        foreach (var student in students)
                        {
                            Console.WriteLine($"ID: {student.Id} | Name: {student.Name} | Age: {student.Age} | GPA: {student.GPA}");
                        }
                        break;

                    case "3":
                        Console.Write("Enter student ID to update: ");
                        int updateId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("New name: ");
                        string newName = Console.ReadLine();
                        Console.Write("New age: ");
                        int newAge = Convert.ToInt32(Console.ReadLine());
                        Console.Write("New GPA: ");
                        double newGpa = Convert.ToDouble(Console.ReadLine());

                        Student updatedStudent = new Student { Id = updateId, Name = newName, Age = newAge, GPA = newGpa };
                        repository.UpdateStudent(updatedStudent);
                        Console.WriteLine("Student updated.");
                        break;

                    case "4":
                        Console.Write("Enter student ID to delete: ");
                        int deleteId = Convert.ToInt32(Console.ReadLine());
                        repository.DeleteStudent(deleteId);
                        Console.WriteLine("Student deleted.");
                        break;

                    case "5":
                        isRunning = false;
                        Console.WriteLine("Goodbye!");
                        break;

                    default:
                        Console.WriteLine("Invalid option. Try again.");
                        break;
                }
            }
        }
    }
}
