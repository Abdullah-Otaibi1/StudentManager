﻿using Microsoft.EntityFrameworkCore;
using StudentManager.Models;
using System.Collections.Generic;

namespace StudentManager.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=DESKTOP-62LQ7LF\SQL2022;Database=StudentDB;Trusted_Connection=True;TrustServerCertificate=True;");
        }
    }
}
