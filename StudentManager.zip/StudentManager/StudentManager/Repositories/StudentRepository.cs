﻿using StudentManager.Models;
using StudentManager.Data;
using System.Collections.Generic;
using System.Linq;

namespace StudentManager.Repositories
{
    public class StudentRepository : IRepository
    {
        private readonly AppDbContext context;

        public StudentRepository()
        {
            context = new AppDbContext();
            context.Database.EnsureCreated();
        }

        public void AddStudent(Student student)
        {
            context.Students.Add(student);
            context.SaveChanges();
        }

        public List<Student> GetAllStudents()
        {
            return context.Students.ToList();
        }

        public void UpdateStudent(Student student)
        {
            var existing = context.Students.Find(student.Id);
            if (existing != null)
            {
                existing.Name = student.Name;
                existing.Age = student.Age;
                existing.GPA = student.GPA;
                context.SaveChanges();
            }
        }

        public void DeleteStudent(int id)
        {
            var student = context.Students.Find(id);
            if (student != null)
            {
                context.Students.Remove(student);
                context.SaveChanges();
            }
        }
    }
}
