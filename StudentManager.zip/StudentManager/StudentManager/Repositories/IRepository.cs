﻿using StudentManager.Models;
using System.Collections.Generic;

namespace StudentManager.Repositories
{
    public interface IRepository
    {
        void AddStudent(Student student);
        List<Student> GetAllStudents();
        void UpdateStudent(Student student);
        void DeleteStudent(int id);
    }
}
